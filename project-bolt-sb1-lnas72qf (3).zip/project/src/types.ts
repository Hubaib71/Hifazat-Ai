export interface ScanResult {
  score: number;
  level: 'low' | 'medium' | 'high';
  label: string;
  risks: string[];
  recommendations: string[];
  source: string;
  explanationUrdu: string;
}

export type ScanStatus = 'idle' | 'scanning' | 'done' | 'error';

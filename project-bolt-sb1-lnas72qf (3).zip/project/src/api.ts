import type { ScanResult } from '@/types';

interface ApiCheckResponse {
  score: number;
  level: 'low' | 'medium' | 'high';
  reasons: string[];
  explanation_urdu: string;
}

function levelToLabel(
  level: 'low' | 'medium' | 'high',
  labels: { high: string; medium: string; low: string },
): string {
  return labels[level] ?? labels.low;
}

function recommendationsForLevel(
  level: 'low' | 'medium' | 'high',
  recs: { high: string[]; medium: string[]; low: string[] },
): string[] {
  if (level === 'high') return recs.high;
  if (level === 'medium') return recs.medium;
  return recs.low;
}

interface RiskRule {
  reasonEn: string;
  reasonUr: string;
  weight: number;
  patternsEn: RegExp[];
  patternsUr: RegExp[];
}

const rules: RiskRule[] = [
  {
    reasonEn: 'Uses a URL shortener (bit.ly, tinyurl) which hides the real destination',
    reasonUr: 'شارٹ لنک استعمال ہوا ہے جو اصل ویب سائٹ کو چھپاتا ہے',
    weight: 15,
    patternsEn: [/\b(bit\.ly|tinyurl\.com|t\.co|goo\.gl|shorturl\.at|is\.gd|buff\.ly|rebrand\.ly|cutt\.ly|shorte\.st)\b/],
    patternsUr: [],
  },
  {
    reasonEn: 'Contains an IP address instead of a domain name — common in phishing',
    reasonUr: 'ڈومین کے بجائے آئی پی ایڈریس استعمال ہوا ہے — فشنگ کی علامت',
    weight: 20,
    patternsEn: [/https?:\/\/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/],
    patternsUr: [],
  },
  {
    reasonEn: 'Uses lots of subdomains to mimic a trusted brand',
    reasonUr: 'قابل اعتماد برانڈ کی نقل کے لیے زیادہ سب ڈومین استعمال ہوئے ہیں',
    weight: 15,
    patternsEn: [/\b([a-z0-9-]+\.){3,}[a-z]{2,}\b/],
    patternsUr: [],
  },
  {
    reasonEn: 'Domain has many hyphens — often used in fake URLs',
    reasonUr: 'ڈومین میں بہت زیادہ ہائفن ہیں — جعلی لنک کی علامت',
    weight: 10,
    patternsEn: [/([a-z]-){3,}/, /(^|\s)[-a-z]{0,10}-[a-z]{0,10}-[a-z]{0,10}-[a-z]{0,10}\./],
    patternsUr: [],
  },
  {
    reasonEn: 'Promises cash prizes, lottery wins, or free rewards',
    reasonUr: 'نقد انعام، لاٹری، یا مفت تحفے کا وعدہ کیا گیا ہے',
    weight: 20,
    patternsEn: [/\b(lottery|lucky draw|cash prize|free reward|won|winner|congratulations?|prize|jackpot|free gift|claim your|you have been selected)\b/],
    patternsUr: [/(لاٹری|انعام|نقد انعام|مفت|تحفہ| prizes?\s)/],
  },
  {
    reasonEn: 'Urgency language: "act now", "limited time", "last chance"',
    reasonUr: 'فوری اقدام کا دباؤ: "ابھی کریں"، "محدود وقت"، "آخری موقع"',
    weight: 15,
    patternsEn: [/\b(act now|limited time|last chance|hurry|urgent|immediately|expires? today|today only|don.?t wait|offer ends?|deadline)\b/],
    patternsUr: [/(فوری|ابھی|آخری|محدود وقت|جلد|ابھی کریں|دیر نہ کریں|آخری موقع)/],
  },
  {
    reasonEn: 'Asks for bank account, CNIC, OTP, or password details',
    reasonUr: 'بینک اکاؤنٹ، شناختی کارڈ، او ٹی پی، یا پاس ورڈ مانگا گیا ہے',
    weight: 25,
    patternsEn: [/\b(bank account|cnic|otp|one.?time.?password|password|pin code|credit card|debit card|cvv|atm pin|account number)\b/],
    patternsUr: [/(بینک اکاؤنٹ|شناختی کارڈ|اثبات|او ٹی پی|پاس ورڈ|پن کوڈ|کریڈٹ کارڈ|بینک تفصیلات|اکاؤنٹ نمبر)/],
  },
  {
    reasonEn: 'Mentions upfront fees, registration charges, or advance payments',
    reasonUr: 'پیشگی فیس، رجسٹریشن چارجز، یا ادائیگی کا ذکر ہے',
    weight: 20,
    patternsEn: [/\b(registration fee|processing fee|advance payment|upfront|security deposit|clearance fee|delivery charge|fee required|pay first|send money)\b/],
    patternsUr: [/(رجسٹریشن فیس|فیس|پیشگی|ادائیگی|ضمانت|بھیجیں|رقم بھیج|فیس ادا)/],
  },
  {
    reasonEn: 'Uses a suspicious TLD (.tk, .ml, .ga, .cf) often used by scammers',
    reasonUr: 'مشکوک ٹی ایل ڈی (.tk, .ml, .ga, .cf) جو اسکامرز استعمال کرتے ہیں',
    weight: 15,
    patternsEn: [/\.(tk|ml|ga|cf|gq|top|xyz|click|country|stream|download|review)\b/],
    patternsUr: [],
  },
  {
    reasonEn: 'Contains "WhatsApp" or "WhatsApp number" in a job/earnings context',
    reasonUr: 'کام یا آمدنی کے سیاق و سباق میں واٹس ایپ نمبر کا ذکر ہے',
    weight: 15,
    patternsEn: [/\bwhatsapp\b/, /\b(job|earn|income|work|part.?time|investment|business|profit|daily)\b/],
    patternsUr: [/واٹس\s?ایپ/, /(کام|آمدنی|روزگار|ملازمت|کاروبار|منافع|سرمایہ)/],
  },
  {
    reasonEn: 'Mentions "easy money", "earn from home", or unrealistic income claims',
    reasonUr: '"آسان آمدنی"، "گھر سے کمائی"، یا غیر حقیقی آمدنی کا دعویٰ ہے',
    weight: 18,
    patternsEn: [/\b(easy money|earn from home|work from home|make money online|daily income|guaranteed income|passive income|earn \$?[\d,]+|unlimited earning|become rich|financial freedom)\b/],
    patternsUr: [/(گھر سے|آسان آمدنی|روزانہ آمدنی|گھر بیٹھے|کمائی|بے روزگار|مالی آزادی|امیر بن)/],
  },
  {
    reasonEn: 'Impersonates a government agency (FBR, NADRA, SBP) in a payment context',
    reasonUr: 'ادائیگی کے حوالے سے حکومتی ادارے (ایف بی آر، نادرا، ایس بی پی) کا نام استعمال ہوا ہے',
    weight: 22,
    patternsEn: [/\b(fbr|nadra|sbp|state bank|federal board of revenue)\b/, /\b(tax|refund|payment|fee|penalty|portal|register|verify)\b/],
    patternsUr: [/(\bFBR\b|\bNADRA\b|نادرا|ایف بی آر|ایس بی پی|بینک)/, /(ٹیکس|واپسی|ادائیگی|فیس|جرمانہ|پورٹل|تصدیق)/],
  },
  {
    reasonEn: 'Contains misspelled brand names (paypa1, amaz0n, faceb00k)',
    reasonUr: 'برانڈ کے نام غلط ہجے سے لکھے گئے ہیں',
    weight: 18,
    patternsEn: [/\b(paypa1|amaz0n|arnaz0n|faceb00k|facebo0k|g00gle|goog1e|instaqram|instagrarn|netfl1x|tiktokk|tiiktok|app1e)\b/i],
    patternsUr: [],
  },
  {
    reasonEn: 'Uses HTTP instead of HTTPS — connection is not secure',
    reasonUr: 'ایچ ٹی ٹی پی استعمال ہوا ہے نہ کہ ایچ ٹی ٹی پی ایس — کنکشن غیر محفوظ ہے',
    weight: 12,
    patternsEn: [/\bhttp:\/\/(?!127\.0\.0\.1|localhost)/],
    patternsUr: [],
  },
  {
    reasonEn: 'Contains emoji-heavy promotional text often used in scam ads',
    reasonUr: 'اشتہار میں بہت زیادہ ایموجی استعمال ہوئے ہیں — اسکام اشتہار کی علامت',
    weight: 8,
    patternsEn: [],
    patternsUr: [],
  },
  {
    reasonEn: 'Claims you won a prize or reward without entering any contest',
    reasonUr: 'بغیر کوئی مقابلے میں حصہ لیے انعام جیتنے کا دعویٰ کیا گیا ہے',
    weight: 18,
    patternsEn: [/\b(you won|congratulations.{0,20}won|you have been selected|you are.{0,20}winner|claim your prize)\b/i],
    patternsUr: [/(آپ جیت|مبارک ہو.{0,15}جیت|آپ کو منتخب|آپ فاتح|اپنا انعام)/],
  },
  {
    reasonEn: 'Mentions online shopping scam patterns (fake courier, COD fraud)',
    reasonUr: 'آن لائن شاپنگ اسکام کے نمونے (جعلی کوریئر، کیش آن ڈیلیوری فراڈ)',
    weight: 15,
    patternsEn: [/\b(cash on delivery|cod|courier charge|delivery fee|parcel.{0,10}stuck|custom.{0,10}charge)\b/i],
    patternsUr: [/(کیش آن ڈیلیوری|کرایہ|کوریئر|پارسل|رسید|ڈیلیوری چارجز)/],
  },
];

function analyzeText(
  text: string,
  isUrdu: boolean,
): { score: number; reasons: string[]; explanationUrdu: string } {
  const lower = text.toLowerCase();
  let rawScore = 0;
  const matchedRules: RiskRule[] = [];

  const emojiCount = (text.match(/[\u{1F000}-\u{1FFFF}\u{2600}-\u{27BF}]/gu) || []).length;

  for (const rule of rules) {
    let matched = false;

    if (rule.patternsEn.length > 0) {
      if (rule.reasonEn === 'Contains emoji-heavy promotional text often used in scam ads') {
        matched = emojiCount >= 4;
      } else if (rule.patternsEn.length === 1) {
        matched = rule.patternsEn[0].test(lower);
      } else {
        matched = rule.patternsEn.every((p) => p.test(lower));
      }
    }

    if (!matched && rule.patternsUr.length > 0) {
      matched = rule.patternsUr.every((p) => p.test(text));
    }

    if (matched) {
      matchedRules.push(rule);
      rawScore += rule.weight;
    }
  }

  const score = Math.min(rawScore, 100);
  const reasons = matchedRules.map((r) => (isUrdu ? r.reasonUr : r.reasonEn));
  const urduReasons = matchedRules.map((r) => r.reasonUr);

  let explanationUrdu: string;
  if (score >= 60) {
    const topReasons = urduReasons.length > 0 ? urduReasons.slice(0, 3).join('، ') : 'متعدد خطرات';
    explanationUrdu = `یہ لنک انتہائی خطرناک ہے۔ ${topReasons}۔ براہ کرم اس لنک پر اعتبار نہ کریں اور فوری طور پر ایف آئی اے سائبر کرائم (1991) میں رپورٹ کریں۔`;
  } else if (score >= 30) {
    const topReasons = urduReasons.length > 0 ? urduReasons.slice(0, 2).join('، ') : 'احتیاط کریں';
    explanationUrdu = `اس لنک میں کچھ خطرات ہیں۔ ${topReasons}۔ آگے بڑھنے سے پہلے کمپنی یا لنک کی خود تصدیق کریں۔`;
  } else {
    explanationUrdu = `اس لنک میں کوئی خاص خطرہ نہیں ملا، تاہم ہمیشہ احتیاط کریں اور اپنی ذاتی معلومات کبھی شیئر نہ کریں۔`;
  }

  return { score, reasons, explanationUrdu };
}

function levelFromScore(score: number): 'low' | 'medium' | 'high' {
  if (score >= 60) return 'high';
  if (score >= 30) return 'medium';
  return 'low';
}

export async function checkScam(
  text: string,
  sourceLabel: string,
  labels: { high: string; medium: string; low: string },
  recs: { high: string[]; medium: string[]; low: string[] },
  isUrdu: boolean,
): Promise<ScanResult> {
  await new Promise((resolve) => setTimeout(resolve, 1500));

  const analysis = analyzeText(text, isUrdu);
  const level = levelFromScore(analysis.score);

  const data: ApiCheckResponse = {
    score: analysis.score,
    level,
    reasons: analysis.reasons,
    explanation_urdu: analysis.explanationUrdu,
  };

  return {
    score: data.score,
    level: data.level,
    label: levelToLabel(data.level, labels),
    risks: data.reasons,
    recommendations: recommendationsForLevel(data.level, recs),
    source: sourceLabel,
    explanationUrdu: data.explanation_urdu,
  };
}

import { ShieldCheck, Zap, Lock } from 'lucide-react';
import UrduPattern from './UrduPattern';
import ScamChecker from './ScamChecker';
import { useLanguage } from '@/i18n/LanguageContext';

export default function Hero() {
  const { t, isUrdu } = useLanguage();

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-hifazat-50/80 via-white to-white pt-28 pb-20 lg:pt-36 lg:pb-28">
      {/* Urdu pattern background */}
      <div className="absolute inset-0 text-hifazat-700">
        <UrduPattern opacity={0.5} />
      </div>

      {/* Decorative gradient orbs */}
      <div className="absolute -top-20 -right-20 h-72 w-72 rounded-full bg-hifazat-200/30 blur-3xl" />
      <div className="absolute top-40 -left-20 h-64 w-64 rounded-full bg-hifazat-100/40 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Trust badges */}
        <div className="mx-auto mb-6 flex max-w-fit items-center gap-3 rounded-full border border-hifazat-100 bg-white/80 px-4 py-2 shadow-sm backdrop-blur animate-fade-in">
          <div className="flex -space-x-2">
            {[
              <ShieldCheck key="1" className="h-4 w-4 text-hifazat-600" />,
              <Lock key="2" className="h-4 w-4 text-hifazat-600" />,
              <Zap key="3" className="h-4 w-4 text-hifazat-600" />,
            ].map((icon, i) => (
              <div
                key={i}
                className="flex h-6 w-6 items-center justify-center rounded-full border-2 border-white bg-hifazat-50"
              >
                {icon}
              </div>
            ))}
          </div>
          <span className={`text-xs font-semibold text-hifazat-700 ${isUrdu ? 'urdu-text' : ''}`}>
            {t.hero.badge}
          </span>
        </div>

        {/* Heading */}
        <div className="mx-auto max-w-3xl text-center">
          <h1
            className={`font-display text-4xl font-bold tracking-tight text-hifazat-800 text-balance sm:text-5xl lg:text-6xl animate-fade-in-up ${isUrdu ? 'urdu-text-center' : ''}`}
            style={isUrdu ? { lineHeight: '2' } : undefined}
          >
            {t.hero.title}
            <span
              className="block bg-gradient-to-r from-hifazat-600 to-hifazat-800 bg-clip-text text-transparent"
              style={isUrdu ? { marginTop: '0.75rem', lineHeight: '1.9', paddingBottom: '0.3em', paddingTop: '0.3em' } : { marginTop: '0.5rem' }}
            >
              {t.hero.subtitle}
            </span>
          </h1>

          <p
            className={`mt-5 text-lg font-medium text-hifazat-600 text-balance sm:text-xl animate-fade-in-up ${isUrdu ? 'urdu-text-center' : ''}`}
            style={{ animationDelay: '0.1s', lineHeight: isUrdu ? '2.2' : undefined }}
          >
            {t.hero.tagline}
            <span className="font-bold text-hifazat-700">{t.hero.taglineBold}</span>
          </p>

          {/* Secondary line — shows the other language's tagline */}
          <p className={`mt-3 text-base text-hifazat-500 animate-fade-in-up ${isUrdu ? 'urdu-text-center' : 'font-urdu'}`} style={{ animationDelay: '0.2s', lineHeight: '2' }}>
            {t.hero.urduLine}
          </p>
        </div>

        {/* Scam Checker Card */}
        <div className="mt-12 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
          <ScamChecker />
        </div>
      </div>
    </section>
  );
}

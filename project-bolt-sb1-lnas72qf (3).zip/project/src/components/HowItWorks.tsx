import { ClipboardPaste, Cpu, FileCheck } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';

const ICONS = [ClipboardPaste, Cpu, FileCheck];

export default function HowItWorks() {
  const { t, isUrdu } = useLanguage();

  return (
    <section id="how-it-works" className="relative scroll-mt-20 bg-white py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className={`inline-block rounded-full bg-hifazat-100 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-hifazat-700 ${isUrdu ? 'urdu-text-center' : ''}`}>
            {t.howItWorks.badge}
          </span>
          <h2 className={`mt-4 font-display text-3xl font-bold text-hifazat-800 text-balance sm:text-4xl ${isUrdu ? 'urdu-text-center' : ''}`}>
            {t.howItWorks.title}
          </h2>
          <p className={`mt-3 text-base text-hifazat-500 ${isUrdu ? 'urdu-text-center' : ''}`}>
            {t.howItWorks.subtitle}
          </p>
        </div>

        <div className="relative mt-16">
          {/* Connecting line */}
          <div className="absolute left-1/2 top-0 hidden h-full w-px -translate-x-1/2 bg-gradient-to-b from-hifazat-100 via-hifazat-200 to-hifazat-100 lg:block" />

          <div className="space-y-12 lg:space-y-0">
            {t.howItWorks.steps.map((step, i) => {
              const Icon = ICONS[i];
              return (
                <div
                  key={i}
                  className={`relative flex flex-col gap-6 lg:flex-row lg:items-center ${
                    i % 2 === 1 ? 'lg:flex-row-reverse' : ''
                  }`}
                >
                  {/* Content */}
                  <div className="flex-1 lg:px-12">
                    <div
                      className="group rounded-2xl border border-hifazat-100 bg-white p-6 shadow-sm transition-all hover:shadow-lg hover:shadow-hifazat-900/5 lg:max-w-md"
                      style={{ animation: `fadeInUp 0.5s ease-out ${i * 0.15}s both` }}
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-2xl bg-hifazat-50 transition-colors group-hover:bg-hifazat-700">
                          <Icon className="h-7 w-7 text-hifazat-700 transition-colors group-hover:text-white" />
                        </div>
                        <div>
                          <span className={`font-mono text-xs font-bold text-hifazat-300 ${isUrdu ? 'urdu-text' : ''}`}>
                            {t.howItWorks.stepPrefix} {String(i + 1).padStart(2, '0')}
                          </span>
                          <h3 className={`font-display text-lg font-bold text-hifazat-800 ${isUrdu ? 'urdu-text' : ''}`}>
                            {step.title}
                          </h3>
                        </div>
                      </div>
                      <p className={`mt-3 text-sm leading-relaxed text-hifazat-500 ${isUrdu ? 'urdu-text' : ''}`}>
                        {step.description}
                      </p>
                    </div>
                  </div>

                  {/* Center dot */}
                  <div className="relative z-10 hidden h-4 w-4 flex-shrink-0 items-center justify-center lg:flex">
                    <div className="h-4 w-4 rounded-full border-4 border-white bg-hifazat-600 shadow-md" />
                  </div>

                  {/* Spacer */}
                  <div className="hidden flex-1 lg:block" />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

import { TrendingUp, Users, ShieldX, Clock } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';

const ICONS = [Users, ShieldX, Clock, TrendingUp];

export default function Stats() {
  const { t, isUrdu } = useLanguage();

  return (
    <section className="relative border-y border-hifazat-100 bg-white py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-6 lg:grid-cols-4">
          {t.stats.map((stat, i) => {
            const Icon = ICONS[i];
            return (
              <div
                key={i}
                className="flex flex-col items-center text-center sm:flex-row sm:text-left gap-3 sm:gap-4"
                style={{ animation: `fadeInUp 0.5s ease-out ${i * 0.1}s both` }}
              >
                <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-hifazat-50">
                  <Icon className="h-6 w-6 text-hifazat-700" />
                </div>
                <div className={isUrdu ? 'urdu-text' : ''}>
                  <p className="font-display text-2xl font-bold text-hifazat-800" style={isUrdu ? { lineHeight: '1.6' } : undefined}>{stat.value}</p>
                  <p className="text-sm font-semibold text-hifazat-600" style={isUrdu ? { marginTop: '6px', lineHeight: '2' } : undefined}>{stat.label}</p>
                  <p className="text-xs text-hifazat-400" style={isUrdu ? { lineHeight: '2' } : undefined}>{stat.sublabel}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

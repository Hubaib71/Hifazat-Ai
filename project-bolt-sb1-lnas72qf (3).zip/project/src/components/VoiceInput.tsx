import { useState, useRef, useEffect, useCallback } from 'react';
import { Mic, MicOff, RotateCcw, Shield, AlertCircle } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';

interface Props {
  onScan: (transcript: string) => void;
  disabled: boolean;
  onActiveChange?: (active: boolean) => void;
}

type VoiceStatus = 'idle' | 'recording' | 'stopped' | 'unsupported';

type SpeechRecognitionCtor = new () => SpeechRecognition;

const SpeechRecognitionAPI =
  typeof window !== 'undefined'
    ? (window.SpeechRecognition ||
        (window as Window & { webkitSpeechRecognition?: SpeechRecognitionCtor })
          .webkitSpeechRecognition)
    : undefined;

function formatTime(secs: number): string {
  const m = Math.floor(secs / 60).toString().padStart(2, '0');
  const s = (secs % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

export default function VoiceInput({ onScan, disabled, onActiveChange }: Props) {
  const { t, isUrdu } = useLanguage();
  const vt = t.checker.voice;

  const [status, setStatus] = useState<VoiceStatus>(
    SpeechRecognitionAPI ? 'idle' : 'unsupported',
  );
  const [transcript, setTranscript] = useState('');
  const [interim, setInterim] = useState('');
  const [elapsed, setElapsed] = useState(0);
  const [error, setError] = useState('');
  const [errorCode, setErrorCode] = useState('');

  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const autoStopRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const elapsedRef = useRef(0);

  const clearTimers = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (autoStopRef.current) clearTimeout(autoStopRef.current);
    timerRef.current = null;
    autoStopRef.current = null;
  }, []);

  const stopRecognition = useCallback(() => {
    clearTimers();
    const rec = recognitionRef.current;
    recognitionRef.current = null;
    if (rec) {
      try {
        rec.stop();
      } catch {
        /* already stopped */
      }
    }
    setInterim('');
    setStatus((prev) => (prev === 'recording' ? 'stopped' : prev));
  }, [clearTimers]);

  useEffect(() => {
    return () => {
      clearTimers();
      const rec = recognitionRef.current;
      recognitionRef.current = null;
      if (rec) {
        try {
          rec.abort();
        } catch {
          /* already stopped */
        }
      }
    };
  }, [clearTimers]);

  const errorMessageFor = useCallback(
    (code: string): string => {
      switch (code) {
        case 'not-allowed':
        case 'permission-denied':
          return vt.errPermission;
        case 'no-speech':
          return vt.errNoSpeech;
        case 'network':
          return vt.errNetwork;
        case 'audio-capture':
          return vt.errAudioCapture;
        case 'language-not-supported':
          return vt.errLangNotSupported;
        default:
          return vt.errGeneral;
      }
    },
    [vt],
  );

  const startRecording = useCallback(async (langOverride?: string) => {
    if (!SpeechRecognitionAPI) return;
    setError('');
    setErrorCode('');
    setTranscript('');
    setInterim('');
    setElapsed(0);
    elapsedRef.current = 0;

    // 1. Request mic permission via getUserMedia first
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((track) => track.stop());
    } catch {
      setError(vt.errPermission);
      setErrorCode('not-allowed');
      setStatus('idle');
      return;
    }

    // 2. Create a fresh SpeechRecognition instance
    const recognition = new SpeechRecognitionAPI();
    const lang = langOverride ?? (isUrdu ? 'ur-IN' : 'en-US');
    recognition.lang = lang;
    recognition.continuous = true;
    recognition.interimResults = true;
    recognitionRef.current = recognition;

    recognition.onstart = () => {
      setStatus('recording');
      timerRef.current = setInterval(() => {
        elapsedRef.current += 1;
        setElapsed(elapsedRef.current);
      }, 1000);
      autoStopRef.current = setTimeout(() => {
        stopRecognition();
      }, 60000);
    };

    recognition.onresult = (e: SpeechRecognitionEvent) => {
      let interimText = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const result = e.results[i];
        if (result.isFinal) {
          const text = result[0].transcript;
          if (text) setTranscript((prev) => prev + text);
        } else {
          interimText += result[0].transcript;
        }
      }
      setInterim(interimText);
    };

    recognition.onerror = (e: SpeechRecognitionErrorEvent) => {
      if (e.error === 'aborted') return;

      clearTimers();

      // If the Urdu locale fails, retry with the generic "ur" tag before giving up
      if (isUrdu && lang === 'ur-IN' && (e.error === 'network' || e.error === 'language-not-supported')) {
        recognitionRef.current = null;
        try { recognition.abort(); } catch { /* noop */ }
        startRecording('ur');
        return;
      }

      setError(errorMessageFor(e.error));
      setErrorCode(e.error);
      setStatus('idle');
    };

    recognition.onend = () => {
      clearTimers();
      setInterim('');
      setStatus((s) => (s === 'recording' ? 'stopped' : s));
    };

    // 3. Start recognition — never called twice since we create fresh each time
    try {
      recognition.start();
    } catch {
      try {
        recognition.abort();
      } catch {
        /* noop */
      }
      recognitionRef.current = null;
      setStatus('idle');
    }
  }, [clearTimers, errorMessageFor, isUrdu, stopRecognition, vt.errPermission]);

  const handleReset = useCallback(() => {
    stopRecognition();
    setTranscript('');
    setInterim('');
    setElapsed(0);
    setError('');
    setErrorCode('');
    setStatus('idle');
  }, [stopRecognition]);

  const handleCheck = useCallback(() => {
    const text = transcript.trim();
    if (text) onScan(text);
  }, [transcript, onScan]);

  useEffect(() => {
    const active = status === 'recording' || (status === 'stopped' && !!transcript);
    onActiveChange?.(active);
  }, [status, transcript, onActiveChange]);

  if (status === 'unsupported') {
    return (
      <div className="rounded-xl border border-amber-100 bg-amber-50/60 p-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="h-5 w-5 flex-shrink-0 text-amber-500 mt-0.5" />
          <p
            className={`text-sm text-amber-800 ${isUrdu ? 'urdu-text' : ''}`}
            style={isUrdu ? { lineHeight: '2' } : undefined}
          >
            {vt.errUnsupported}
          </p>
        </div>
      </div>
    );
  }

  const isRecording = status === 'recording';
  const hasStopped = status === 'stopped';
  const combinedText = transcript + interim;
  const textDir = isUrdu ? 'rtl' : 'ltr';

  return (
    <div className="space-y-4">
      {/* Mic button + status */}
      <div className="flex flex-col items-center gap-3">
        <div className="relative">
          {/* Pulse rings when recording */}
          {isRecording && (
            <>
              <span className="absolute inset-0 rounded-full bg-red-400 opacity-30 animate-ping" />
              <span
                className="absolute -inset-2 rounded-full bg-red-300 opacity-15 animate-ping"
                style={{ animationDelay: '0.15s' }}
              />
            </>
          )}
          <button
            onClick={isRecording ? stopRecognition : () => startRecording()}
            disabled={disabled}
            className={`relative flex h-20 w-20 items-center justify-center rounded-full shadow-lg transition-all duration-300 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed ${
              isRecording
                ? 'bg-red-500 hover:bg-red-600 shadow-red-300'
                : 'bg-hifazat-700 hover:bg-hifazat-800 shadow-hifazat-300'
            }`}
            aria-label={isRecording ? vt.stopRecording : vt.tapToSpeak}
          >
            {isRecording ? (
              <MicOff className="h-8 w-8 text-white" strokeWidth={2} />
            ) : (
              <Mic className="h-8 w-8 text-white" strokeWidth={2} />
            )}
          </button>
        </div>

        {/* Status text + timer */}
        <div className="text-center">
          {isRecording ? (
            <div className="space-y-1">
              <p
                className={`text-sm font-semibold text-red-600 ${isUrdu ? 'urdu-text' : ''}`}
                style={isUrdu ? { lineHeight: '2' } : undefined}
              >
                {vt.listening}
              </p>
              <p className="font-mono text-xl font-bold text-hifazat-800">
                {formatTime(elapsed)}
              </p>
            </div>
          ) : (
            <p
              className={`text-sm text-hifazat-400 ${isUrdu ? 'urdu-text' : ''}`}
              style={isUrdu ? { lineHeight: '2' } : undefined}
            >
              {vt.tapToSpeak}
            </p>
          )}
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="rounded-xl border border-red-100 bg-red-50/60 p-3">
          <div className="flex items-start gap-2">
            <AlertCircle className="h-4 w-4 flex-shrink-0 text-red-500 mt-0.5" />
            <div className="flex-1">
              <p
                className={`text-sm text-red-700 ${isUrdu ? 'urdu-text' : ''}`}
                style={isUrdu ? { lineHeight: '2' } : undefined}
              >
                {error}
              </p>
              {errorCode && (
                <p className="mt-1 font-mono text-xs text-red-400">
                  {vt.errorCode}: {errorCode}
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Live transcript box — shown once there's any text */}
      {(isRecording || hasStopped || combinedText) && (
        <div className="space-y-2">
          <textarea
            dir={textDir}
            value={combinedText}
            onChange={(e) => {
              if (!isRecording) setTranscript(e.target.value);
            }}
            readOnly={isRecording}
            rows={4}
            placeholder={vt.transcriptPlaceholder}
            className={`w-full resize-none rounded-xl border-2 border-hifazat-100 bg-hifazat-50/50 p-4 text-sm text-hifazat-900 placeholder:text-hifazat-300 transition-all focus:border-hifazat-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-hifazat-500/10 ${
              isUrdu ? 'urdu-text' : ''
            }`}
            style={{ lineHeight: '2.2' }}
          />
          {isRecording && interim && (
            <p
              className={`px-1 text-xs text-hifazat-300 ${isUrdu ? 'urdu-text' : ''}`}
              style={isUrdu ? { lineHeight: '2' } : undefined}
            >
              {interim}
            </p>
          )}
        </div>
      )}

      {/* Action buttons after stopping */}
      {hasStopped && (
        <div className="flex gap-3">
          <button
            data-voice-btn
            onClick={handleReset}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl border-2 border-hifazat-100 py-3 text-sm font-semibold text-hifazat-600 transition-colors hover:bg-hifazat-50"
          >
            <RotateCcw className="h-4 w-4 flex-shrink-0" />
            <span className={isUrdu ? 'urdu-text' : ''}>{vt.reRecord}</span>
          </button>
          <button
            data-voice-btn
            onClick={handleCheck}
            disabled={!transcript.trim() || disabled}
            className="group relative flex flex-1 items-center justify-center gap-2 overflow-hidden rounded-xl bg-gradient-to-r from-hifazat-700 to-hifazat-800 py-3 text-sm font-bold text-white shadow-lg shadow-hifazat-700/25 transition-all hover:shadow-xl hover:shadow-hifazat-700/30 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none"
          >
            <Shield className="h-4 w-4 flex-shrink-0" strokeWidth={2.5} />
            <span className={isUrdu ? 'urdu-text' : ''}>{vt.checkTranscript}</span>
            <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
          </button>
        </div>
      )}
    </div>
  );
}

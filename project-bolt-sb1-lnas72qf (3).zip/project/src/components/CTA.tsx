import UrduPattern from './UrduPattern';
import { Shield, ArrowRight, ArrowLeft, Phone } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';

export default function CTA() {
  const { t, isUrdu } = useLanguage();

  return (
    <section id="verify" className="relative scroll-mt-20 overflow-hidden bg-hifazat-800 py-20 lg:py-24">
      {/* Pattern overlay */}
      <div className="absolute inset-0 text-white">
        <UrduPattern opacity={0.06} />
      </div>

      {/* Glow */}
      <div className="absolute -bottom-20 left-1/2 h-64 w-96 -translate-x-1/2 rounded-full bg-hifazat-600/30 blur-3xl" />

      <div className="relative mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/10 backdrop-blur ring-1 ring-white/20 animate-float">
          <Shield className="h-8 w-8 text-white" strokeWidth={2.5} />
        </div>

        <h2 className={`font-display text-3xl font-bold text-white text-balance sm:text-4xl lg:text-5xl ${isUrdu ? 'urdu-text-center' : ''}`}>
          {t.cta.title}
        </h2>
        <p className={`mx-auto mt-4 max-w-xl text-lg text-hifazat-100 ${isUrdu ? 'urdu-text-center' : ''}`}>
          {t.cta.subtitle}
        </p>

        {/* Urdu / English secondary line */}
        <p className={`mt-3 text-base text-hifazat-200 ${isUrdu ? 'urdu-text-center' : 'font-urdu'}`} style={{ lineHeight: '2' }}>
          {t.cta.urduLine}
        </p>

        <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <a
            href="#checker"
            className="group inline-flex items-center gap-2 rounded-xl bg-white px-7 py-4 text-base font-bold text-hifazat-800 shadow-xl transition-all hover:shadow-2xl hover:scale-105 active:scale-95"
          >
            {isUrdu ? (
              <>
                <ArrowLeft className="h-5 w-5 flex-shrink-0" />
                <span className="urdu-text">{t.cta.checkNow}</span>
              </>
            ) : (
              <>
                <span>{t.cta.checkNow}</span>
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1 flex-shrink-0" />
              </>
            )}
          </a>
          <a
            href="tel:1991"
            className="inline-flex items-center gap-2 rounded-xl border-2 border-white/20 bg-white/5 px-7 py-4 text-base font-bold text-white backdrop-blur transition-all hover:bg-white/10"
          >
            <Phone className="h-5 w-5 flex-shrink-0" />
            <span className={isUrdu ? 'urdu-text' : ''}>{t.cta.reportFia}</span>
          </a>
        </div>

        <p className={`mt-6 text-xs font-medium text-hifazat-300 ${isUrdu ? 'urdu-text-center' : ''}`}>
          {t.cta.footer}
        </p>
      </div>
    </section>
  );
}

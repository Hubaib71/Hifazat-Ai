import { useState, useEffect, useCallback } from 'react';
import { Shield, Menu, X, ChevronDown, Languages, Moon, Sun } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';

export default function Navbar() {
  const { t, toggleLang, isUrdu } = useLanguage();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const toggleDarkMode = useCallback(() => {
    setDarkMode(prev => {
      const next = !prev;
      document.documentElement.classList.toggle('dark-mode', next);
      return next;
    });
  }, []);

  const navLinks = [
    { label: t.nav.howItWorks, href: '#how-it-works' },
    { label: t.nav.features, href: '#features' },
    { label: t.nav.verify, href: '#verify' },
    { label: t.nav.about, href: '#about' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'glass shadow-[0_2px_20px_rgba(0,0,0,0.08)] border-b border-hifazat-100'
          : 'bg-transparent'
      }`}
    >
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between lg:h-20">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2.5 group">
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-hifazat-700 shadow-lg shadow-hifazat-700/30 transition-transform group-hover:scale-105">
              <Shield className="h-5 w-5 text-white" strokeWidth={2.5} />
              <div className="absolute inset-0 rounded-xl ring-1 ring-white/20" />
            </div>
            <div className={`flex flex-col ${isUrdu ? 'gap-1' : 'leading-none'}`}>
              <span
                className={`font-display text-lg font-bold tracking-tight text-hifazat-800 ${isUrdu ? 'urdu-text' : ''}`}
                style={isUrdu ? { lineHeight: '1.8' } : undefined}
              >
                {isUrdu ? (
                  <>
                    حفاظت<span className="text-hifazat-500"> اے آئی</span>
                  </>
                ) : (
                  <>
                    Hifazat<span className="text-hifazat-500"> AI</span>
                  </>
                )}
              </span>
              <span
                className={`text-[10px] font-medium tracking-wider text-hifazat-400 uppercase ${isUrdu ? 'urdu-text' : ''}`}
                style={isUrdu ? { lineHeight: '1.6' } : undefined}
              >
                {t.footer.tagline}
              </span>
            </div>
          </a>

          {/* Desktop nav */}
          <div className="hidden items-center gap-1 lg:flex">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="rounded-lg px-4 py-2 text-sm font-semibold text-hifazat-700 transition-colors hover:bg-hifazat-50 hover:text-hifazat-800"
              >
                {link.label}
              </a>
            ))}
            <button
              onClick={toggleLang}
              className="ml-2 flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold text-hifazat-600 hover:bg-hifazat-50 transition-colors"
            >
              <Languages className="h-4 w-4" />
              <span className={isUrdu ? 'urdu-text' : ''}>{t.nav.langLabel}</span>
              <ChevronDown className="h-4 w-4" />
            </button>
            <button
              onClick={toggleDarkMode}
              aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
              className="flex h-9 w-9 items-center justify-center rounded-lg text-hifazat-600 hover:bg-hifazat-50 transition-all duration-200"
            >
              {darkMode
                ? <Sun className="h-4 w-4 text-amber-400" />
                : <Moon className="h-4 w-4" />
              }
            </button>
            <a
              href="#checker"
              className="ml-3 inline-flex items-center gap-2 rounded-xl bg-hifazat-700 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-hifazat-700/25 transition-all hover:bg-hifazat-800 hover:shadow-xl hover:shadow-hifazat-700/30 active:scale-95"
            >
              {t.nav.checkScamScore}
            </a>
          </div>

          {/* Mobile toggle */}
          <div className="flex items-center gap-1 lg:hidden">
            <button
              onClick={toggleDarkMode}
              aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
              className="flex h-10 w-10 items-center justify-center rounded-lg text-hifazat-700 hover:bg-hifazat-50 transition-all duration-200"
            >
              {darkMode
                ? <Sun className="h-5 w-5 text-amber-400" />
                : <Moon className="h-5 w-5" />
              }
            </button>
            <button
              onClick={toggleLang}
              className="flex h-10 w-10 items-center justify-center rounded-lg text-hifazat-700 hover:bg-hifazat-50"
              aria-label="Switch language"
            >
              <Languages className="h-5 w-5" />
            </button>
            <button
              className="flex h-10 w-10 items-center justify-center rounded-lg text-hifazat-700 hover:bg-hifazat-50 lg:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="border-t border-hifazat-100 py-4 lg:hidden">
            <div className="flex flex-col gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="rounded-lg px-4 py-2.5 text-sm font-semibold text-hifazat-700 hover:bg-hifazat-50"
                >
                  {link.label}
                </a>
              ))}
              <a
                href="#checker"
                onClick={() => setMobileOpen(false)}
                className="mt-2 inline-flex items-center justify-center gap-2 rounded-xl bg-hifazat-700 px-5 py-3 text-sm font-bold text-white shadow-lg"
              >
                {t.nav.checkScamScore}
              </a>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}

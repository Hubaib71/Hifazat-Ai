import { useState } from 'react';
import { Building2, Plane, Mic, ChevronDown, ChevronUp } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';

const ICONS = [Building2, Plane, Mic];
const ICON_BGS = ['bg-hifazat-700', 'bg-hifazat-600', 'bg-hifazat-500'];

export default function Features() {
  const { t, isUrdu } = useLanguage();
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const toggleExpand = (i: number) => {
    setExpandedIndex(prev => (prev === i ? null : i));
  };

  return (
    <section id="features" className="relative scroll-mt-20 bg-hifazat-50/40 py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="mx-auto max-w-2xl text-center">
          <span className={`inline-block rounded-full bg-hifazat-100 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-hifazat-700 ${isUrdu ? 'urdu-text-center' : ''}`}>
            {t.features.badge}
          </span>
          <h2 className={`mt-4 font-display text-3xl font-bold text-hifazat-800 text-balance sm:text-4xl ${isUrdu ? 'urdu-text-center' : ''}`}>
            {t.features.title}
          </h2>
          <p className={`mt-3 text-base text-hifazat-500 ${isUrdu ? 'urdu-text-center' : ''}`}>
            {t.features.subtitle}
          </p>
        </div>

        {/* Cards */}
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {t.features.items.map((feature, i) => {
            const Icon = ICONS[i];
            const isExpanded = expandedIndex === i;
            const expandedDetails = (feature as typeof feature & { expandedDetails?: string[] }).expandedDetails ?? [];

            return (
              <div
                key={i}
                className={`group relative rounded-2xl border bg-white shadow-sm transition-all duration-300 hover:shadow-xl hover:shadow-hifazat-900/10 ${
                  isExpanded ? 'border-hifazat-300 shadow-lg shadow-hifazat-900/10' : 'border-hifazat-100 hover:-translate-y-1'
                }`}
                style={{ animation: `fadeInUp 0.5s ease-out ${i * 0.15}s both` }}
              >
                {/* Top accent bar */}
                <div className={`absolute inset-x-0 top-0 h-1 rounded-t-2xl ${ICON_BGS[i]} ${isExpanded ? 'opacity-100' : 'opacity-0 transition-opacity group-hover:opacity-100'}`} />

                <div className="p-7">
                  {/* Icon */}
                  <div className={`flex h-14 w-14 items-center justify-center rounded-2xl ${ICON_BGS[i]} shadow-lg transition-transform group-hover:scale-110`}>
                    <Icon className="h-7 w-7 text-white" strokeWidth={2} />
                  </div>

                  {/* Badge */}
                  <div className="mt-5 flex items-center gap-2">
                    <span className="rounded-full bg-hifazat-50 px-3 py-1 text-xs font-bold text-hifazat-700">
                      {feature.badge}
                    </span>
                    <span className="font-urdu text-sm text-hifazat-400">{feature.urdu}</span>
                  </div>

                  {/* Title & description */}
                  <h3
                    className={`font-display text-xl font-bold text-hifazat-800 ${isUrdu ? 'urdu-text' : ''}`}
                    style={isUrdu ? { marginTop: '12px', lineHeight: '1.9' } : { marginTop: '12px' }}
                  >
                    {feature.title}
                  </h3>
                  <p
                    className={`text-sm leading-relaxed text-hifazat-500 ${isUrdu ? 'urdu-text' : ''}`}
                    style={isUrdu ? { marginTop: '8px', lineHeight: '2.6', paddingTop: '0.3em', paddingBottom: '0.3em' } : { marginTop: '8px' }}
                  >
                    {feature.description}
                  </p>

                  {/* Points */}
                  <ul className={`mt-5 ${isUrdu ? 'space-y-2.5' : 'space-y-2'}`}>
                    {feature.points.map((point, pi) => (
                      <li key={pi} className={`flex items-center gap-2 text-sm font-medium text-hifazat-600 ${isUrdu ? 'urdu-text' : ''}`} style={isUrdu ? { lineHeight: '2.4' } : undefined}>
                        <div className="flex h-4 w-4 items-center justify-center rounded-full bg-hifazat-100 flex-shrink-0">
                          <div className="h-1.5 w-1.5 rounded-full bg-hifazat-600" />
                        </div>
                        {point}
                      </li>
                    ))}
                  </ul>

                  {/* Learn more button */}
                  <button
                    onClick={() => toggleExpand(i)}
                    className={`mt-5 flex w-full items-center gap-1.5 text-sm font-bold transition-colors ${
                      isExpanded ? 'text-hifazat-700' : 'text-hifazat-500 hover:text-hifazat-700'
                    } ${isUrdu ? 'urdu-text justify-end' : 'justify-start'}`}
                  >
                    <span className={isUrdu ? 'urdu-text' : ''}>{t.features.learnMore}</span>
                    {isExpanded ? (
                      <ChevronUp className="h-4 w-4 flex-shrink-0 transition-transform" />
                    ) : (
                      <ChevronDown className="h-4 w-4 flex-shrink-0 transition-transform" />
                    )}
                  </button>
                </div>

                {/* Expanded details */}
                {isExpanded && expandedDetails.length > 0 && (
                  <div className="border-t border-hifazat-100 px-7 pb-7 pt-5 animate-fade-in">
                    <div className="space-y-4">
                      {expandedDetails.map((detail, di) => (
                        <div key={di} className={`flex gap-3 ${isUrdu ? 'flex-row-reverse' : ''}`}>
                          <div className={`mt-1.5 flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full ${ICON_BGS[i]} text-white`}>
                            <span className="text-[10px] font-bold">{di + 1}</span>
                          </div>
                          <p
                            className={`text-sm leading-relaxed text-hifazat-600 ${isUrdu ? 'urdu-text' : ''}`}
                            style={isUrdu ? { lineHeight: '2.4' } : { lineHeight: '1.7' }}
                          >
                            {detail}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

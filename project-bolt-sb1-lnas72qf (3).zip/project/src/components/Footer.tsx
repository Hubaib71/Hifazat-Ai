import { Shield, Mail, Phone, MapPin, Heart } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';

export default function Footer() {
  const { t, isUrdu } = useLanguage();

  return (
    <footer id="about" className="scroll-mt-20 border-t border-hifazat-100 bg-white">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        {/* Row 1: Brand + link columns spread full width */}
        <div className="flex flex-col gap-10 lg:flex-row lg:items-start lg:justify-between">
          {/* Brand */}
          <div className="lg:max-w-xs xl:max-w-sm">
            <div className="flex items-center gap-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-hifazat-700 shadow-lg shadow-hifazat-700/30">
                <Shield className="h-5 w-5 text-white" strokeWidth={2.5} />
              </div>
              <div className={`flex flex-col ${isUrdu ? 'gap-1' : 'leading-none'}`}>
                <span
                  className={`font-display text-lg font-bold text-hifazat-800 ${isUrdu ? 'urdu-text' : ''}`}
                  style={isUrdu ? { lineHeight: '1.8' } : undefined}
                >
                  {isUrdu ? (
                    <>
                      حفاظت<span className="text-hifazat-500"> اے آئی</span>
                    </>
                  ) : (
                    <>
                      Hifazat<span className="text-hifazat-500"> AI</span>
                    </>
                  )}
                </span>
                <span
                  className={`text-[10px] font-medium tracking-wider text-hifazat-400 uppercase ${isUrdu ? 'urdu-text' : ''}`}
                  style={isUrdu ? { lineHeight: '1.6' } : undefined}
                >
                  {t.footer.tagline}
                </span>
              </div>
            </div>
            <p className={`mt-4 text-sm leading-relaxed text-hifazat-500 ${isUrdu ? 'urdu-text' : ''}`}>
              {t.footer.description}
            </p>
            <div className="mt-5 space-y-2">
              <div className="flex items-center gap-2 text-sm text-hifazat-500">
                <Mail className="h-4 w-4 text-hifazat-400 flex-shrink-0" />
                hello@hifazat.ai
              </div>
            </div>
          </div>

          {/* Link columns — spread across the remaining width */}
          <div className="flex flex-1 flex-col gap-8 sm:flex-row sm:justify-between sm:gap-6">
            {Object.entries(t.footer.categories).map(([category, links]) => (
              <div key={category} className={isUrdu ? 'text-right' : ''}>
                <h4
                  className={`font-display text-sm font-bold uppercase tracking-wider text-hifazat-700 ${isUrdu ? 'urdu-text' : ''}`}
                  style={isUrdu ? { lineHeight: '1.8' } : undefined}
                >
                  {category}
                </h4>
                <ul className={`mt-4 ${isUrdu ? 'space-y-3' : 'space-y-2.5'}`}>
                  {links.map((link, i) => (
                    <li key={i}>
                      <a
                        href="#"
                        className={`text-sm text-hifazat-500 transition-colors hover:text-hifazat-700 ${isUrdu ? 'block urdu-text' : ''}`}
                        style={isUrdu ? { lineHeight: '1.8' } : undefined}
                      >
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Row 2: Helpline & location — below link columns, aligned per language */}
        <div
          className={`mt-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-6 ${
            isUrdu ? 'sm:justify-end' : 'sm:justify-start'
          }`}
        >
          <div
            className={`flex items-center gap-2 text-sm text-hifazat-500 ${isUrdu ? 'urdu-text' : ''}`}
            style={isUrdu ? { lineHeight: '2' } : undefined}
          >
            <Phone className="h-4 w-4 text-hifazat-400 flex-shrink-0" />
            <span className="whitespace-nowrap">{t.footer.fiaCyberCrime}</span>
          </div>
          <div
            className={`flex items-center gap-2 text-sm text-hifazat-500 ${isUrdu ? 'urdu-text' : ''}`}
            style={isUrdu ? { lineHeight: '2' } : undefined}
          >
            <MapPin className="h-4 w-4 text-hifazat-400 flex-shrink-0" />
            <span>{t.footer.islamabad}</span>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-hifazat-100 pt-6 sm:flex-row">
          <p className={`text-xs text-hifazat-400 ${isUrdu ? 'urdu-text' : ''}`}>
            {t.footer.copyright}
          </p>
          <p className={`flex items-center gap-1.5 text-xs text-hifazat-400 ${isUrdu ? 'urdu-text' : ''}`}>
            {t.footer.madeWith} <Heart className="h-3 w-3 fill-red-500 text-red-500 flex-shrink-0" /> {t.footer.forPakistan}
          </p>
          <div className="flex items-center gap-3">
            <span className={`rounded-full bg-hifazat-50 px-3 py-1 text-xs font-semibold text-hifazat-600 ${isUrdu ? 'urdu-text-center' : ''}`}>
              {t.footer.proudlyPakistani}
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}

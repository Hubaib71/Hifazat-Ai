import { useState, useRef, useCallback } from 'react';
import VoiceInput from '@/components/VoiceInput';
import { checkScam } from '@/api';
import {
  Shield,
  Link2,
  UploadCloud,
  FileImage,
  X,
  ArrowRight,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  ShieldAlert,
  Sparkles,
  ScanLine,
  AlertCircle,
  RotateCcw,
  Languages,
} from 'lucide-react';
import type { ScanResult, ScanStatus } from '@/types';
import { useLanguage } from '@/i18n/LanguageContext';

export default function ScamChecker() {
  const { t, isUrdu } = useLanguage();
  const [link, setLink] = useState('');
  const [fileName, setFileName] = useState<string | null>(null);
  const [voiceActive, setVoiceActive] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [status, setStatus] = useState<ScanStatus>('idle');
  const [result, setResult] = useState<ScanResult | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const linkActive = !!link.trim();
  const imageActive = !!fileName;
  const anyInputActive = linkActive || imageActive || voiceActive;

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFileName(e.dataTransfer.files[0].name);
    }
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFileName(e.target.files[0].name);
    }
  }, []);

  const runScan = useCallback(
    async (text: string, sourceLabel: string) => {
      setStatus('scanning');
      setResult(null);
      setErrorMsg('');
      try {
        const res = await checkScam(text, sourceLabel, t.checker.scoreLabels, {
          high: t.checker.recsHigh,
          medium: t.checker.recsMedium,
          low: t.checker.recsLow,
        }, isUrdu);
        setResult(res);
        setStatus('done');
      } catch {
        setErrorMsg(t.checker.errorApi);
        setStatus('error');
      }
    },
    [t, isUrdu],
  );

  const handleScan = useCallback(() => {
    if (!link && !fileName) return;
    const text = link || fileName || '';
    const sourceLabel = !link && !!fileName ? t.checker.sourceLabels.image : t.checker.sourceLabels.link;
    runScan(text, sourceLabel);
  }, [link, fileName, t, runScan]);

  const handleReset = useCallback(() => {
    setLink('');
    setFileName(null);
    setVoiceActive(false);
    setStatus('idle');
    setResult(null);
    setErrorMsg('');
  }, []);

  const handleVoiceScan = useCallback(
    (transcript: string) => {
      setLink('');
      setFileName(null);
      runScan(transcript, t.checker.sourceLabels.link);
    },
    [t, runScan],
  );

  const handleErrorRetry = useCallback(() => {
    setStatus('idle');
    setResult(null);
    setErrorMsg('');
  }, []);

  const scoreColor =
    result && result.level === 'high'
      ? 'text-red-600'
      : result && result.level === 'medium'
      ? 'text-accent-600'
      : 'text-hifazat-600';

  const scoreBg =
    result && result.level === 'high'
      ? 'from-red-500 to-red-700'
      : result && result.level === 'medium'
      ? 'from-accent-400 to-accent-600'
      : 'from-hifazat-500 to-hifazat-700';

  const ScoreIcon =
    result && result.level === 'high'
      ? ShieldAlert
      : result && result.level === 'medium'
      ? AlertTriangle
      : CheckCircle2;

  return (
    <div id="checker" className="relative w-full max-w-2xl mx-auto scroll-mt-24">
      {/* Glow */}
      <div className="absolute -inset-1 rounded-3xl bg-gradient-to-br from-hifazat-400/20 via-hifazat-600/10 to-transparent blur-2xl" />

      <div className="relative rounded-3xl border border-hifazat-100 bg-white p-6 shadow-2xl shadow-hifazat-900/10 sm:p-8">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-hifazat-50">
              <ScanLine className="h-5 w-5 text-hifazat-700" />
            </div>
            <div>
              <h3 className={`font-display text-base font-bold text-hifazat-800 ${isUrdu ? 'urdu-text' : ''}`}>{t.checker.title}</h3>
              <p className={`text-xs text-hifazat-400 ${isUrdu ? 'urdu-text' : ''}`}>{t.checker.subtitle}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 rounded-full bg-hifazat-50 px-3 py-1">
            <Sparkles className="h-3.5 w-3.5 text-hifazat-600" />
            <span className={`text-xs font-semibold text-hifazat-600 ${isUrdu ? 'urdu-text' : ''}`}>{t.checker.fiveSecondCheck}</span>
          </div>
        </div>

        {/* Input sections — mutually exclusive: Voice, Link, Screenshot */}
        <div className="space-y-4">

          {/* 1. Voice section — shown when no other input is active */}
          {!linkActive && !imageActive && (
            <div>
              <label className={`mb-3 block text-sm font-semibold text-hifazat-700 ${isUrdu ? 'urdu-text' : ''}`}>
                {t.checker.voice.sectionTitle}
              </label>
              <VoiceInput
                onScan={handleVoiceScan}
                disabled={status === 'scanning'}
                onActiveChange={setVoiceActive}
              />
              {voiceActive && (
                <button
                  onClick={() => setVoiceActive(false)}
                  className={`mt-3 flex w-full items-center justify-center gap-2 rounded-xl border-2 border-hifazat-100 py-2.5 text-sm font-semibold text-hifazat-600 transition-colors hover:bg-hifazat-50 ${isUrdu ? 'urdu-text' : ''}`}
                >
                  <X className="h-4 w-4 flex-shrink-0" />
                  {isUrdu ? 'منسوخ کریں' : 'Cancel voice'}
                </button>
              )}
            </div>
          )}

          {/* OR divider — only when no input is active */}
          {!anyInputActive && (
            <div className="flex items-center gap-4">
              <div className="h-px flex-1 bg-hifazat-100" />
              <span className="text-xs font-bold uppercase tracking-wider text-hifazat-300">{t.checker.or}</span>
              <div className="h-px flex-1 bg-hifazat-100" />
            </div>
          )}

          {/* 2. Link input — shown when no image and no voice active */}
          {!imageActive && !voiceActive && (
            <div>
              <label className={`mb-2 block text-sm font-semibold text-hifazat-700 ${isUrdu ? 'urdu-text' : ''}`}>
                {t.checker.pasteLink}
              </label>
              <div className="group relative">
                <Link2 className={`pointer-events-none absolute top-4 h-5 w-5 text-hifazat-400 transition-colors group-focus-within:text-hifazat-600 ${isUrdu ? 'right-4' : 'left-4'}`} />
                <textarea
                  data-link-input
                  ref={inputRef}
                  rows={1}
                  value={link}
                  onChange={(e) => {
                    setLink(e.target.value);
                    const el = e.target;
                    const prevHeight = el.style.height;
                    el.style.height = 'auto';
                    const newHeight = `${el.scrollHeight}px`;
                    if (prevHeight !== newHeight) {
                      const scrollY = window.scrollY;
                      el.style.height = newHeight;
                      window.scrollTo({ top: scrollY, behavior: 'instant' as ScrollBehavior });
                    } else {
                      el.style.height = prevHeight;
                    }
                  }}
                  onFocus={(e) => {
                    const scrollY = window.scrollY;
                    requestAnimationFrame(() => window.scrollTo({ top: scrollY, behavior: 'instant' as ScrollBehavior }));
                  }}
                  placeholder={t.checker.placeholder}
                  dir={isUrdu ? 'rtl' : 'ltr'}
                  className={`w-full resize-none overflow-hidden rounded-xl border-2 border-hifazat-100 bg-hifazat-50/50 py-3.5 text-sm font-medium text-hifazat-900 placeholder:text-hifazat-300 placeholder:text-xs transition-[border-color,background-color,box-shadow] focus:border-hifazat-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-hifazat-500/10 ${isUrdu ? 'pr-12 pl-4 text-right' : 'pl-12 pr-4'}`}
                  style={{ minHeight: '52px' }}
                />
              </div>
            </div>
          )}

          {/* OR divider — only when no input is active */}
          {!anyInputActive && (
            <div className="flex items-center gap-4">
              <div className="h-px flex-1 bg-hifazat-100" />
              <span className="text-xs font-bold uppercase tracking-wider text-hifazat-300">{t.checker.or}</span>
              <div className="h-px flex-1 bg-hifazat-100" />
            </div>
          )}

          {/* 3. Drag & drop — shown when no link and no voice active */}
          {!linkActive && !voiceActive && (
            <div>
              <label className={`mb-2 block text-sm font-semibold text-hifazat-700 ${isUrdu ? 'urdu-text' : ''}`}>
                {t.checker.uploadScreenshot}
              </label>
              <div
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`relative cursor-pointer rounded-xl border-2 border-dashed p-6 text-center transition-all ${
                  dragActive
                    ? 'border-hifazat-500 bg-hifazat-50 scale-[1.01]'
                    : 'border-hifazat-200 bg-hifazat-50/30 hover:border-hifazat-400 hover:bg-hifazat-50/60'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                {fileName ? (
                  <div className="flex items-center justify-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-hifazat-100">
                      <FileImage className="h-5 w-5 text-hifazat-700" />
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-semibold text-hifazat-800">{fileName}</p>
                      <p className="text-xs text-hifazat-400">{t.checker.clickToChange}</p>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setFileName(null);
                      }}
                      className="ml-2 flex h-7 w-7 items-center justify-center rounded-full bg-hifazat-100 text-hifazat-500 hover:bg-red-100 hover:text-red-600"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-hifazat-100 transition-transform group-hover:scale-110">
                      <UploadCloud className="h-6 w-6 text-hifazat-600" />
                    </div>
                    <p className={`text-sm font-semibold text-hifazat-700 ${isUrdu ? 'urdu-text-center' : ''}`}>
                      {t.checker.dragDrop}
                    </p>
                    <p className={`text-xs text-hifazat-400 ${isUrdu ? 'urdu-text-center' : ''}`}>{t.checker.fileTypes}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Check button — only when link or image is active */}
          {(linkActive || imageActive) && !voiceActive && (
            <button
              data-check-btn
              onClick={handleScan}
              disabled={status === 'scanning'}
              className="group relative w-full overflow-hidden rounded-xl bg-gradient-to-r from-hifazat-700 to-hifazat-800 py-4 text-center text-base font-bold text-white shadow-xl shadow-hifazat-700/25 transition-all hover:shadow-2xl hover:shadow-hifazat-700/30 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none"
            >
              <span className="relative z-10 flex items-center justify-center gap-2">
                {status === 'scanning' ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    {t.checker.scanning}
                  </>
                ) : (
                  <>
                    <Shield className="h-5 w-5" strokeWidth={2.5} />
                    {t.checker.checkScamScore}
                    <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
                  </>
                )}
              </span>
              <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
            </button>
          )}
        </div>

        {/* Scanning animation */}
        {status === 'scanning' && (
          <div className="mt-6 overflow-hidden rounded-xl border border-hifazat-100 bg-hifazat-50/50 p-4">
            <div className="flex items-center gap-3">
              <div className="relative flex h-10 w-10 items-center justify-center">
                <div className="absolute inset-0 rounded-full border-2 border-hifazat-200" />
                <div className="absolute inset-0 rounded-full border-2 border-hifazat-600 border-t-transparent animate-spin" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <p className={`text-sm font-semibold text-hifazat-700 ${isUrdu ? 'urdu-text' : ''}`}>{t.checker.analyzing}</p>
                  <span className="font-mono text-xs text-hifazat-400">{t.checker.aiEngine}</span>
                </div>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-hifazat-100">
                  <div className="h-full w-1/3 rounded-full bg-gradient-to-r from-hifazat-500 to-hifazat-700 shimmer-bg" style={{ animation: 'shimmer 1.5s linear infinite' }} />
                </div>
                <div className="mt-2 flex gap-2">
                  {t.checker.scanSteps.map((step, i) => (
                    <span
                      key={i}
                      className="rounded-full bg-white px-2 py-0.5 text-[10px] font-medium text-hifazat-500 shadow-sm"
                      style={{ animation: `fadeIn 0.3s ease-out ${i * 0.3}s both` }}
                    >
                      {step}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Error state */}
        {status === 'error' && (
          <div className="mt-6 animate-scale-in rounded-xl border border-amber-200 bg-amber-50/60 p-5">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 flex-shrink-0 text-amber-500 mt-0.5" />
              <div className="flex-1">
                <p className={`text-sm font-semibold text-amber-800 ${isUrdu ? 'urdu-text' : ''}`}>
                  {t.checker.errorTitle}
                </p>
                <p className={`mt-1 text-sm text-amber-700 ${isUrdu ? 'urdu-text' : ''}`}>
                  {errorMsg}
                </p>
                <button
                  onClick={handleErrorRetry}
                  className="mt-3 inline-flex items-center gap-2 rounded-lg border border-amber-300 px-4 py-2 text-sm font-semibold text-amber-800 transition-colors hover:bg-amber-100"
                >
                  <RotateCcw className="h-4 w-4 flex-shrink-0" />
                  {isUrdu ? 'دوبارہ کوشش کریں' : t.checker.checkAnother}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Results */}
        {status === 'done' && result && (
          <div className="mt-6 animate-scale-in space-y-4">
            {/* Score gauge */}
            <div data-score-card className="rounded-2xl border border-hifazat-100 bg-gradient-to-br from-hifazat-50/50 to-white p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${scoreBg} shadow-lg`}>
                    <ScoreIcon className="h-7 w-7 text-white" />
                  </div>
                  <div>
                    <p className={`text-xs font-semibold uppercase tracking-wider text-hifazat-400 ${isUrdu ? 'urdu-text' : ''}`}>
                      {result.source}
                    </p>
                    <p className={`font-display text-lg font-bold ${scoreColor} ${isUrdu ? 'urdu-text' : ''}`}>{result.label}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-mono text-4xl font-bold text-hifazat-800">
                    {result.score}
                    <span className="text-xl text-hifazat-300">/100</span>
                  </p>
                  <p className={`text-xs font-medium text-hifazat-400 ${isUrdu ? 'urdu-text' : ''}`}>{t.checker.scamScore}</p>
                </div>
              </div>

              {/* Score bar */}
              <div className="mt-4">
                <div className="h-2.5 overflow-hidden rounded-full bg-hifazat-100">
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${scoreBg} transition-all duration-1000`}
                    style={{ width: `${result.score}%` }}
                  />
                </div>
                <div className="mt-1.5 flex justify-between text-[10px] font-medium text-hifazat-300">
                  <span>{t.checker.safe}</span>
                  <span>{t.checker.caution}</span>
                  <span>{t.checker.scam}</span>
                </div>
              </div>
            </div>

            {/* Urdu explanation from API */}
            {result.explanationUrdu && (
              <div className="rounded-xl border border-hifazat-200 bg-hifazat-50/50 p-4">
                <p className={`mb-2 flex items-center gap-2 text-sm font-bold text-hifazat-700`}>
                  <Languages className="h-4 w-4 flex-shrink-0" />
                  {t.checker.urduExplanation}
                </p>
                <p className="font-urdu text-sm text-hifazat-800" dir="rtl" style={{ lineHeight: '2.4' }}>
                  {result.explanationUrdu}
                </p>
              </div>
            )}

            {/* Risk factors */}
            <div className="rounded-xl border border-red-100 bg-red-50/50 p-4">
              <p className={`mb-2 flex items-center gap-2 text-sm font-bold text-red-700 ${isUrdu ? 'urdu-text' : ''}`}>
                <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                {t.checker.riskFactors}
              </p>
              {result.risks.length > 0 ? (
                <ul className="space-y-1.5">
                  {result.risks.map((risk, i) => (
                    <li key={i} className={`flex items-start gap-2 text-sm text-red-800 ${isUrdu ? 'urdu-text' : ''}`}>
                      <span className="mt-1.5 h-1 w-1 flex-shrink-0 rounded-full bg-red-500" />
                      {risk}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className={`text-sm text-hifazat-600 ${isUrdu ? 'urdu-text' : ''}`}>
                  {t.checker.noRisksFound}
                </p>
              )}
            </div>

            {/* Recommendations */}
            <div className="rounded-xl border border-hifazat-200 bg-hifazat-50/50 p-4">
              <p className={`mb-2 flex items-center gap-2 text-sm font-bold text-hifazat-700 ${isUrdu ? 'urdu-text' : ''}`}>
                <Shield className="h-4 w-4 flex-shrink-0" />
                {t.checker.whatYouShouldDo}
              </p>
              <ul className="space-y-1.5">
                {result.recommendations.map((rec, i) => (
                  <li key={i} className={`flex items-start gap-2 text-sm text-hifazat-800 ${isUrdu ? 'urdu-text' : ''}`}>
                    <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-hifazat-600" />
                    {rec}
                  </li>
                ))}
              </ul>
            </div>

            {/* Reset */}
            <button
              data-reset-btn
              onClick={handleReset}
              className="w-full rounded-xl border-2 border-hifazat-100 py-3 text-sm font-semibold text-hifazat-600 transition-colors hover:bg-hifazat-50"
            >
              {t.checker.checkAnother}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

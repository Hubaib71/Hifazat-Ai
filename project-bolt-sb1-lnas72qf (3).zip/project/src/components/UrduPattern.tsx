interface PatternProps {
  className?: string;
  opacity?: number;
}

export default function UrduPattern({ className = '', opacity = 1 }: PatternProps) {
  return (
    <svg
      className={`absolute inset-0 h-full w-full ${className}`}
      style={{ opacity }}
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <pattern
          id="urdu-star"
          x="0"
          y="0"
          width="80"
          height="80"
          patternUnits="userSpaceOnUse"
        >
          <g stroke="currentColor" strokeWidth="0.6" fill="none">
            <path d="M40 5 L50 30 L75 30 L55 47 L63 72 L40 57 L17 72 L25 47 L5 30 L30 30 Z" opacity="0.5" />
            <circle cx="40" cy="40" r="18" opacity="0.3" />
            <path d="M40 25 L40 55 M25 40 L55 40" opacity="0.2" />
            <path d="M28 28 L52 52 M52 28 L28 52" opacity="0.15" />
          </g>
        </pattern>
        <pattern
          id="urdi-grid"
          x="0"
          y="0"
          width="120"
          height="120"
          patternUnits="userSpaceOnUse"
        >
          <g stroke="currentColor" strokeWidth="0.4" fill="none">
            <path d="M0 60 H120 M60 0 V120" opacity="0.1" />
            <circle cx="60" cy="60" r="3" opacity="0.2" fill="currentColor" />
            <path d="M55 60 Q60 55 65 60 Q60 65 55 60 Z" opacity="0.25" />
          </g>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#urdu-star)" />
      <rect width="100%" height="100%" fill="url(#urdi-grid)" />
    </svg>
  );
}

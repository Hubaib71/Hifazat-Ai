import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { translations, type Lang } from './translations';

type TranslationMap = typeof translations.en;

interface LanguageContextValue {
  lang: Lang;
  t: TranslationMap;
  isUrdu: boolean;
  toggleLang: () => void;
  setLang: (lang: Lang) => void;
}

const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>('en');

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = 'ltr';
    document.documentElement.classList.toggle('lang-urdu', lang === 'ur');
  }, [lang]);

  const toggleLang = () => setLang((prev) => (prev === 'en' ? 'ur' : 'en'));

  const value: LanguageContextValue = {
    lang,
    t: translations[lang],
    isUrdu: lang === 'ur',
    toggleLang,
    setLang,
  };

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider');
  return ctx;
}
